from django.shortcuts import render

from django.http import HttpResponse

def about_us(request):
    return render(request,'page/about_us.html')

def team(request):
    return render(request,'page/team.html')

def testimonials(request):
    return render(request,'page/testimonials.html')

def service(request):
    return render(request,'page/service.html')

def portfolio(request):
    return render(request,'page/portfolio.html')

def portfolio_details_page(request):
    return render(request,'page/portfolio_details_page.html')

def pricing(request):
    return render(request,'page/pricing.html')

def blog(request):
    return render(request,'page/blog.html')

def single_blog_post(request):
    return render(request,'page/single_blog_page.html')

def contact(request):
    return render(request,'page/contact.html')

def asp(request):
    return render(request,'page/asp.html')