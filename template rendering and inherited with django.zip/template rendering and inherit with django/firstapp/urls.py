from django.urls import path
from.import views
urlpatterns = [
    path('about_us/',views.about_us,name='about_us'),
    path('team/',views.team,name='team'),
    path('testimonials/',views.testimonials,name='testimonials'),
    path('services/',views.service,name='services'),
    path('portfolio/',views.portfolio,name='portfolio'),
    path('portfolio_details_page/',views.portfolio_details_page,name='portfolio_details_page'),
    path('pricing/',views.pricing,name='pricing'),
    path('blog/',views.blog,name='blog'),
    path('single_blog_post/',views.single_blog_post,name='single_blog_section'),
    path('contact/',views.contact,name='contact'),
    path('asp/',views.asp,name='asp'),
]